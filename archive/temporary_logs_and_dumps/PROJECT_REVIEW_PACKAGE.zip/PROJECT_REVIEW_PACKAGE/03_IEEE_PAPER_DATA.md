# IEEE Paper Preparation Data: ResearchNexus AI

## 1. Title Suggestions
- An Explainable Research Assistant Using Hybrid Retrieval, XAI, and Enhanced RAG
- ResearchNexus AI: A System for Explainable, Context-Bound Academic Question Answering
- Integrating Hybrid Retrieval and Iterative RAG for Transparent Research Assistance
- Towards Transparent Academic Search: A Hybrid RAG Architecture with Explicit Citation Verification

## 2. Abstract Draft
With the rapid expansion of scientific literature, researchers increasingly rely on large language models for literature review and synthesis. However, existing retrieval-augmented generation (RAG) systems often suffer from hallucinated citations, lack of transparency, and poor retrieval for domain-specific queries. We present ResearchNexus AI, an explainable research assistant built on a hybrid retrieval architecture and an enhanced RAG pipeline. Our approach combines sparse BM25 and dense ChromaDB retrieval using Reciprocal Rank Fusion, followed by BGE cross-encoder reranking. To ensure transparency, we implement a 10-stage local execution timeline that exposes the full retrieval and generation trace to the user. Additionally, the system employs context-bound generation with deterministic and semantic claim verification for citation repair. The proposed architecture evaluates an iterative refinement process to mitigate unsupported claims and enforce scope constraints. In this paper, we describe the system architecture and outline our planned evaluation on a multi-domain corpus of 706 papers alongside established online academic repositories. Our evaluation plan aims to assess retrieval performance, citation precision, and system latency. *Note: All empirical evaluations are currently planned, and this paper presents the system design and hypotheses.*

## 3. Keywords
- Retrieval-Augmented Generation (RAG)
- Hybrid Retrieval
- Explainable AI (XAI)
- Scientific Document Retrieval
- Citation Verification
- Cross-Encoder Reranking
- Iterative Refinement
- Natural Language Processing

## 4. Introduction Points
- **The Problem:** The exponential growth of scientific literature makes thorough literature reviews time-consuming, while LLMs alone are prone to hallucination and lack up-to-date domain knowledge.
- **Current Limitations:** Existing academic search tools (e.g., standard RAG) lack transparency in how answers are derived and often fail to accurately verify claims against the retrieved text.
- **The Need for Transparency:** Explainability (XAI) is critical in academic research; users must trust the provenance of the synthesized information.
- **Proposed Solution:** ResearchNexus AI introduces a context-bound, scope-enforced enhanced RAG system with a transparent 10-stage execution timeline.
- **Key Mechanisms:** Integration of hybrid retrieval (BM25 + Dense + RRF + BGE Reranking) and deterministic/semantic claim verification with iterative refinement to improve citation accuracy.
- **Evaluation Plan:** We present our system design and propose a comprehensive experimental framework to test retrieval efficacy, generation accuracy, and system efficiency.

## 5. Related Work
- **General Academic Search (Google Scholar, Semantic Scholar):** Focus on keyword/graph-based retrieval but lack generative synthesis and direct question answering.
- **LLM-Based Search (Perplexity):** Provide generative answers with citations but operate as black boxes with limited transparency and less strict citation verification.
- **OpenScholar:** A state-of-the-art open-source LLM for literature synthesis. ResearchNexus differentiates by emphasizing an explainable workspace and explicitly exposing the reasoning trace, though operating on a smaller local scale.
- **Traditional RAG:** Relies primarily on single-stage dense retrieval, often missing exact keyword matches crucial for scientific entities.
- **Hybrid RAG:** Combines sparse and dense methods. Our work builds on this by adding robust cross-encoder reranking, strict claim verification, and an iterative refinement cycle.
*(Note: No direct experimental comparison is claimed; differences are architectural and conceptual.)*

## 6. OpenScholar Positioning Table

| Dimension | OpenScholar | ResearchNexus AI (Proposed) |
| :--- | :--- | :--- |
| **Scale** | Large-scale parameter model, cloud-oriented | Local/Modular (React + FastAPI + Gemini Flash) |
| **Corpus** | Massive web-scale academic corpus | Curated (706 papers, 26,179 chunks) + 5 Online Sources |
| **Retriever** | Proprietary/Optimized Dense | Hybrid (BM25 + ChromaDB) with RRF(k=60) |
| **Reranker** | Integrated/Proprietary | Explicit BGE cross-encoder (BAAI/bge-reranker-base) |
| **Iteration** | Multi-step reasoning internal to model | Explicit 2-cycle max, self-feedback, anti-oscillation |
| **Citation Verification** | Implicit in generation | Explicit: deterministic + semantic (5 statuses), citation repair |
| **XAI** | Limited trace visibility | High: 10-stage local timeline with full trace transparency |
| **Research Workspace** | Interface-focused | 5 modes, 5 scopes, SHA-256 context hashing, immutable snapshots |

## 7. Proposed Method
- **System Architecture:** A modular stack comprising a React frontend, FastAPI backend, PostgreSQL database, and ChromaDB vector store, utilizing Gemini Flash for generation.
- **Hybrid Retrieval Pipeline:** Queries are processed simultaneously by BM25 (sparse) and ChromaDB using BAAI/bge-base-en-v1.5 (dense). Results are merged via Reciprocal Rank Fusion (RRF, k=60).
- **Reranking:** Merged results are scored by the BAAI/bge-reranker-base model to maximize top-K relevance.
- **Context Engine:** Manages retrieval state across 5 modes (e.g., QA, Summary) and 5 scopes (e.g., local only, online only). Uses SHA-256 hashing to create immutable context snapshots for reproducibility.
- **Enhanced RAG Generation:** Context-bound generation strict on evidence. Output is grounded in retrieved chunks.
- **Claim Verification & Repair:** Post-generation module checks every claim deterministically and semantically against context, classifying into 5 statuses (e.g., Supported, Unsupported, Contradicted) and repairing citations.
- **Iterative Refinement:** If verification fails or claims are unsupported, a self-feedback loop triggers (max 2 cycles) with anti-oscillation safeguards to refine the answer.
- **XAI Timeline:** A 10-stage execution pipeline is tracked, logging latencies, decisions, and intermediate states, exposed directly to the user UI.

## 8. Experimental Design
*(Note: All metrics and results discussed here are TARGETS / HYPOTHESES to be tested.)*
- **Exp 1: BM25 vs Dense vs Hybrid** - Evaluate recall and precision differences between isolated retrievers and the RRF hybrid combination.
- **Exp 2: Effect of RRF** - Compare varying 'k' values in Reciprocal Rank Fusion against simple score averaging.
- **Exp 3: Effect of BGE Reranking** - Measure MRR and nDCG@K before and after the cross-encoder reranking step.
- **Exp 4: Enhanced RAG vs Basic RAG** - Compare standard dense retrieval + generation against the full context-bound generation pipeline on citation precision.
- **Exp 5: Claim Verification Impact** - Measure the reduction in unsupported claims after the deterministic and semantic verification stage is applied.
- **Exp 6: Single-pass vs Iterative RAG** - Assess output quality and time cost when allowing 1 vs 2 cycles of iterative refinement.
- **Exp 7: Local vs Online vs Hybrid Scopes** - Evaluate answer comprehensiveness and latency across different context engine scopes.
- **Exp 8: Latency Analysis** - Breakdown of P50/P95 latencies across the 10-stage pipeline to identify bottlenecks.

## 9. Baselines
*(Note: Baselines are structural configurations for planned experiments.)*
1. **LLM-Only (Zero-shot):** Gemini Flash without any context injection.
2. **Standard Dense RAG:** ChromaDB (Dense) + LLM.
3. **Standard Sparse RAG:** BM25 + LLM.
4. **Hybrid RAG (No Reranker):** BM25 + Dense + RRF + LLM.
5. **Hybrid RAG + Reranker:** BM25 + Dense + RRF + BGE Reranker + LLM.
6. **Full System (Single-pass):** Reranked Hybrid + Context Engine + Claim Verification (no iteration).
7. **Full System (Iterative):** The complete ResearchNexus AI pipeline with max 2 refinement cycles.

## 10. Metrics
*(Note: Metrics represent the planned evaluation criteria.)*
- **Retrieval Metrics:**
  - Recall@K, Precision@K
  - Mean Reciprocal Rank (MRR)
  - Normalized Discounted Cumulative Gain (nDCG@K)
  - Hit@K
- **Generation & Faithfulness Metrics:**
  - Claim Support Rate (TARGET: % of claims fully supported by context)
  - Citation Precision (TARGET: accuracy of inline citations)
  - Citation Coverage (TARGET: proportion of context utilized)
  - Unsupported Claim Rate (TARGET: frequency of hallucinations/unbacked statements)
- **Efficiency Metrics:**
  - System Latency: P50 and P95 latency (in milliseconds) broken down by pipeline stage.

## 11. Results Tables (EMPTY)
*(Note: These tables are placeholders. NO experimental results have been measured yet.)*

**Table 1: Dataset Distribution**
| Domain | Paper Count | Chunk Count | Avg Chunks/Paper |
| :--- | :--- | :--- | :--- |
| Domain A | - | - | - |
| Domain B | - | - | - |
| Domain C | - | - | - |
| **Total** | **706** | **26,179** | - |

**Table 2: Retrieval Results (Target)**
| Method | Hit@5 | Hit@10 | Recall@10 | Precision@5 |
| :--- | :--- | :--- | :--- | :--- |
| BM25 | - | - | - | - |
| Dense | - | - | - | - |
| Hybrid | - | - | - | - |

**Table 3: Reranking Comparison (Target)**
| Method | MRR | nDCG@5 | nDCG@10 |
| :--- | :--- | :--- | :--- |
| Hybrid (No Rerank) | - | - | - |
| Hybrid + BGE Rerank | - | - | - |

**Table 4: Citation Verification Results (Target)**
| Configuration | Supported % | Unsupported % | Contradicted % |
| :--- | :--- | :--- | :--- |
| Basic Prompting | - | - | - |
| With Verification Module | - | - | - |

**Table 5: Iterative Refinement Comparison (Target)**
| Cycles | Claim Support Rate | Citation Precision | Latency (ms) |
| :--- | :--- | :--- | :--- |
| 1 Pass | - | - | - |
| 2 Passes | - | - | - |

**Table 6: Latency (Target)**
| Stage | P50 (ms) | P95 (ms) |
| :--- | :--- | :--- |
| Hybrid Retrieval | - | - |
| Reranking | - | - |
| Generation | - | - |
| Verification | - | - |
| **Total End-to-End** | - | - |

**Table 7: Ablation Study (Target)**
| System Variant | Recall@10 | Citation Precision | Claim Support Rate |
| :--- | :--- | :--- | :--- |
| Full System | - | - | - |
| - Iteration | - | - | - |
| - Verification | - | - | - |
| - Reranking | - | - | - |
| - Hybrid (Dense Only) | - | - | - |

## 12. Ablation Study Design
To understand the contribution of each system component, we plan the following ablation path (removing one component at a time from the full system):
1. **Full System:** Hybrid + Reranking + Verification + Iteration
2. **- Iteration:** Remove the 2-cycle self-feedback loop (single pass only).
3. **- Verification:** Remove the deterministic and semantic claim verification/citation repair step.
4. **- Reranking:** Remove the BAAI/bge-reranker-base cross-encoder.
5. **- Hybrid (Dense Only):** Remove BM25 sparse retrieval (revert to pure ChromaDB dense retrieval).

## 13. Evaluation Dataset Structure
To rigorously evaluate the system, we propose a curated question dataset with the following schema:
- **ID:** Unique identifier for the evaluation query.
- **Question:** The academic query (e.g., "What are the limitations of contrastive learning in X?").
- **Domain:** One of the 3 domains covered by the local corpus.
- **Expected Papers:** List of gold-standard paper IDs/DOIs containing the answer.
- **Answer Type:** e.g., Factoid, List, Summary, Comparative.
- **Difficulty:** Easy (explicit in one paper), Medium (synthesized from one paper), Hard (cross-document synthesis).

## 14. Experiment Tracking Record Schema
For organized evaluation tracking, each experiment run will log:
- **Run ID & Timestamp**
- **Experiment Type:** e.g., Retrieval, Generation, End-to-End.
- **System Configuration:** Snapshot of hyperparams (RRF k, Reranker threshold, scopes enabled).
- **Dataset Subset:** e.g., Domain A, Hard difficulty only.
- **Aggregated Metrics:** Dict of metrics (Recall, Precision, Latency).
- **Context Snapshot Hash:** SHA-256 hash of the retrieved context for reproducibility.
- **Failure Log:** IDs of queries that timed out or failed verification.

## 15. Research Contributions
- **System Contribution:** The design and implementation of an end-to-end open-source research assistant (ResearchNexus AI) emphasizing local execution, modularity, and explicit transparency via a 10-stage execution timeline.
- **Engineering Contribution:** Efficient integration of dense and sparse retrieval with cross-encoder reranking, coupled with a robust 5-mode, 5-scope Context Engine featuring immutable context hashing.
- **Research Hypothesis:** The implementation of deterministic and semantic claim verification combined with a controlled (max 2 cycles) iterative refinement loop will significantly increase citation precision and claim support rates compared to standard RAG architectures. *(Target hypothesis to be validated)*.

## 16. Limitations
- **Current Development State:** As of writing, the system is fully implemented in architecture, but all experimental results and comparative metrics remain unmeasured.
- **Latency Overheads:** The multi-stage pipeline, particularly cross-encoder reranking and iterative verification, introduces significant latency compared to basic RAG systems.
- **Scale:** The local corpus is limited to 706 papers, meaning domain generalization beyond these specific 3 domains is untested.
- **Dependency on LLM API:** While execution orchestration is local, the system relies on Gemini Flash, making it susceptible to API rate limits and network variability.

## 17. Conclusion Points
- ResearchNexus AI addresses the critical need for explainability and accuracy in LLM-assisted academic research.
- By structuring the retrieval into a robust hybrid pipeline with reranking, we hypothesize higher recall and precision for complex scientific queries.
- The introduction of a dedicated claim verification and citation repair module, exposed via a transparent XAI timeline, empowers researchers to trust and verify generated content.
- Future work will focus on executing the proposed experimental design to empirically validate the hypothesized improvements against standard RAG baselines.

## 18. References to Verify
*(Key literature references to be integrated and verified in the paper bibliography)*
- OpenScholar architecture and evaluation metrics.
- Reciprocal Rank Fusion (RRF) methodology and optimal parameter selection.
- BGE embeddings and cross-encoder reranking performance benchmarks.
- Foundational papers on Retrieval-Augmented Generation (e.g., Lewis et al., 2020).
- Recent surveys on hallucinations in LLMs and RAG systems.
- Methodologies for semantic claim verification and entailment in QA systems.
