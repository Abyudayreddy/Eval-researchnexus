# Software Requirements Specification (SRS) - Update Report
## ResearchNexus AI: "An Explainable Research Assistant Using Hybrid Retrieval, XAI and Enhanced RAG"

## 1. Project Title, Problem Statement, Objectives
**Project Title:** ResearchNexus AI: An Explainable Research Assistant Using Hybrid Retrieval, XAI and Enhanced RAG
**Problem Statement:** Researchers face challenges efficiently navigating vast volumes of scientific literature, leading to information overload. Traditional search tools lack transparency, and many LLM-based assistants suffer from hallucinations and poor source attribution. There is a need for a research assistant that combines hybrid retrieval, robust explainability (XAI), and enhanced Retrieval-Augmented Generation (RAG) to provide verifiable, transparent, and accurate insights.
**Objectives:**
1. To develop a scalable hybrid retrieval system that integrates local corpus search and multiple online scientific repositories concurrently.
2. To implement a comprehensive Explainable AI (XAI) framework that exposes retrieval decision-making and generation traces to users.
3. To build an Enhanced RAG pipeline featuring strict context scoping, multi-mode assistance, and automated claim verification for reduced hallucinations.
4. To provide an integrated workspace for researchers, combining search, reading, note-taking, and project management.

## 2. Scope
**In Scope:**
- Hybrid search across local dataset (706 papers) and 5 online repositories (arXiv, OpenAlex, PMC, AGRIS, NASA ADS).
- XAI features including detailed search timelines, "Why this paper?" explanations, and trace displays.
- User management, authentication, and basic analytics tracking.
- Paper library, bookmarking, and project association.
- Notebook functionality for research notes.
- AI Assistant Workspace with 5 modes, context scoping, and iterative refinement.
- Claim verification with deterministic and semantic checks.

**Out of Scope (for current phase):**
- Full knowledge base management.
- Complete implementation of the user-upload pipeline for personal corpora (currently partial).
- Advanced literature review theme organizer (currently stub).
- Comprehensive experimental evaluation metrics gathering.
- Production deployment (currently config only, deployed locally/Vercel).

## 3. System Architecture
ResearchNexus AI follows a modular client-server architecture:
- **Presentation Layer (Frontend):** React 19 + TypeScript + Vite + TailwindCSS 4 application. State management via Zustand, routing via React Router v7. Integrates PDF viewer, Markdown rendering, and XAI visualizations.
- **API Layer (Backend):** FastAPI in Python handling RESTful endpoints and WebSockets for real-time AI responses and search progress polling.
- **Service Layer (Backend):** Contains domain logic for local retrieval (RRF, BM25, Dense), online connector management, enhanced RAG orchestration, and XAI trace generation.
- **Data Layer:** PostgreSQL for relational data (users, projects, history, metadata, BM25 indices) and ChromaDB for vector embeddings (26,179 chunks).
- **AI/LLM Engine:** Google Gemini 3.5 Flash Lite (primary) for generation and verification, BAAI/bge-base-en-v1.5 for embeddings, BAAI/bge-reranker-base for reranking.

## 4. Functional Requirements

| ID | Description | Priority | Status |
|---|---|---|---|
| FR-01 | **Hybrid Search:** System must search local DB and online repositories concurrently. | High | Implemented & Verified |
| FR-02 | **Local Retrieval:** Must use PostgreSQL ILIKE, BM25, Dense search, and RRF(k=60). | High | Implemented & Verified |
| FR-03 | **Online Retrieval:** Connectors for arXiv, OpenAlex, PMC, AGRIS, NASA ADS. | High | Implemented & Verified |
| FR-04 | **XAI Timelines:** Display detailed execution timelines for local and online search. | High | Implemented & Verified |
| FR-05 | **XAI Explainability:** Provide "Why this paper?" reasoning and trace display. | High | Implemented & Verified |
| FR-06 | **Authentication:** JWT-based user login, registration, and profile management. | High | Implemented & Verified |
| FR-07 | **Dashboard & Analytics:** Display user statistics, search events, and activity heatmaps. | Medium | Implemented & Verified |
| FR-08 | **Paper Reader:** In-app PDF viewer. | High | Implemented & Verified |
| FR-09 | **Library & Notebooks:** Bookmark papers and take notes linked to projects. | High | Implemented & Verified |
| FR-10 | **Project Management:** Create and manage research projects with paper associations. | High | Implemented & Verified |
| FR-11 | **Search History:** Save, favorite, and delete past searches. | Medium | Implemented & Verified |
| FR-12 | **AI Assistant Workspace:** Support 5 modes (research/paper/compare/evidence/upload). | High | Implemented (Not verified) |
| FR-13 | **Context Engine:** Manage context scopes with hashing and eligibility checks. | High | Implemented (Not verified) |
| FR-14 | **Enhanced RAG:** Pipeline with context construction, generation, and verification. | High | Implemented (Not verified) |
| FR-15 | **Claim Verification:** Extract claims and verify against source context; repair citations. | High | Implemented (Not verified) |
| FR-16 | **Iterative Refinement:** Self-feedback and refinement loops (max 2 cycles). | Medium | Implemented (Not verified) |
| FR-17 | **Literature Review:** Abstract-only synthesis and theme organization. | Low | Partially Implemented |
| FR-18 | **Personal Corpus Upload:** Allow users to upload and index personal PDFs. | Medium | Partially Implemented |
| FR-19 | **Settings:** Manage privacy, security, and profile settings. | Low | Partially Implemented |
| FR-20 | **Knowledge Base Management:** Administer the local knowledge base contents. | Low | Deferred |

## 5. Non-Functional Requirements
| ID | Description | Priority |
|---|---|---|
| NFR-01 | **Performance:** Local search should complete within 2 seconds. | High |
| NFR-02 | **Scalability:** Must support up to 50,000 document chunks in local vector DB. | Medium |
| NFR-03 | **Explainability:** AI responses must have traceable provenance linked to source chunks. | High |
| NFR-04 | **Security:** API endpoints must be secured using JWT; passwords hashed with passlib. | High |
| NFR-05 | **Usability:** Frontend must be responsive and accessible, utilizing Radix UI components. | High |
| NFR-06 | **Reliability:** System should handle online repository API rate limits gracefully. | High |
| NFR-07 | **Maintainability:** Codebase follows strict typing (TypeScript/Pydantic) and modular design. | Medium |

## 6. Technology Stack
- **Frontend:** React 19, TypeScript, Vite, TailwindCSS 4, Zustand, React Router v7, Radix UI, Framer Motion, Recharts
- **Backend:** Python, FastAPI, SQLAlchemy, Pydantic
- **Database:** PostgreSQL (relational), ChromaDB (vector)
- **LLM Engine:** Google Gemini 3.5 Flash Lite (primary), 3.1 Flash Lite (fallback), Ollama local (configured, disabled)
- **Embedding Model:** BAAI/bge-base-en-v1.5 (768-dim)
- **Reranker:** BAAI/bge-reranker-base
- **Authentication:** JWT (python-jose + passlib)
- **PDF Processing:** PyPDF, LlamaIndex SentenceSplitter (512 chunk size, 50 overlap)
- **Deployment:** Vercel (frontend), Render (backend planned)

## 7. Current Implementation Summary
The core infrastructure for ResearchNexus AI is fully functional and verified. The hybrid search system effectively merges results from a local dataset of 706 papers (26,179 embeddings) with 5 online repositories. The XAI subsystem successfully exposes system operations to the user through timelines and direct explanations. User management, workspaces, libraries, and PDF reading are robustly implemented. The advanced AI assistant features (Enhanced RAG, Context Scoping, Claim Verification, Iterative Refinement) are implemented but require rigorous experimental validation to ensure efficacy. Features surrounding personal document uploads and literature review synthesis remain incomplete.

## 8. Requirement Traceability Matrix

| Requirement ID | Requirement | Implementation File/Module | Evidence | Status |
|---|---|---|---|---|
| FR-01 | Hybrid Search | `HybridSearchPage`, Backend search router | Concurrent polling UI active | Implemented & Verified |
| FR-02 | Local Retrieval | Backend retrieval pipeline, RRF logic | DB logs show ILIKE+BM25+Dense | Implemented & Verified |
| FR-03 | Online Retrieval | Connectors module | Data fetched from arXiv/OpenAlex | Implemented & Verified |
| FR-04 | XAI Timelines | XAI Timeline components | 10-section/8-stage UI renders | Implemented & Verified |
| FR-05 | XAI Explainability | WhyThisPaper drawer, trace display | Drawer opens with search_id trace | Implemented & Verified |
| FR-06 | Authentication | Auth context, FastAPI auth router | JWT tokens issued and validated | Implemented & Verified |
| FR-07 | Dashboard | Dashboard view, backend stats endpoint | Real stats derived from DB | Implemented & Verified |
| FR-08 | Paper Reader | PDF viewer iframe | Renders PDFs in app | Implemented & Verified |
| FR-09 | Library & Notebooks | Notebook CRUD, Library view | Notes/Bookmarks saved in Postgres | Implemented & Verified |
| FR-10 | Project Management | Projects view, relational DB tables | Projects link to papers/notes | Implemented & Verified |
| FR-11 | Search History | History view, search log table | Histories saved/favorited/deleted | Implemented & Verified |
| FR-12 | AI Workspace | AI Assistant Workspace UI | 5 mode UI active | Implemented |
| FR-13 | Context Engine | Scope engine, snapshots | Scopes hashed and tracked | Implemented |
| FR-14 | Enhanced RAG | RAG orchestration service | Pipeline constructs context | Implemented |
| FR-15 | Claim Verification | Claim extraction service | 6 claim types defined, checks run | Implemented |
| FR-16 | Iterative Refinement | Refinement orchestrator | Cycles implemented, limit set | Implemented |
| FR-17 | Literature Review | Review tools | Stub theme organizer | Partially Implemented |
| FR-18 | Personal Upload | Upload UI, backend stub | UI drop-zone present | Partially Implemented |
| FR-19 | Settings | Settings views | Security/Privacy placeholders | Partially Implemented |
| FR-20 | KB Management | Backend stub | Stub endpoint only | Deferred |
| Eval | Experimental Eval | N/A | No metrics logged | Deferred |

## 9. Known Limitations
- The enhanced RAG and claim verification modules, while code-complete, lack experimental validation against ground truth datasets to determine accuracy and hallucination reduction rates.
- Personal corpus upload is missing the backend indexing pipeline, rendering the frontend drop-zone non-functional for actual processing.
- The literature review theme organizer is currently a stub, limiting the system's ability to synthesize large volumes of papers automatically.
- Security and Privacy settings tabs are currently placeholders without underlying implementation.

## 10. Future Work
- Rigorously test and validate the AI Assistant Workspace and Enhanced RAG pipelines.
- Complete the backend processing pipeline for user-uploaded PDFs to enable true personal knowledge base generation.
- Fully implement the Literature Review theme organizer using LLM-driven clustering.
- Establish comprehensive evaluation metrics and run experiments to quantify the system's effectiveness compared to baseline RAG systems.
- Complete the planned deployment of the backend to Render.
