# Speaking Notes: ResearchNexus AI Faculty Review

**Project:** "An Explainable Research Assistant Using Hybrid Retrieval, XAI and Enhanced RAG"

## Key Facts
- **Corpus:** 706 local papers, 26,179 embeddings, 3 domains
- **Retrieval:** BM25 + Dense (ChromaDB) + RRF(k=60) + BGE reranking
- **Online Sources:** arXiv, OpenAlex, PMC, AGRIS, NASA ADS
- **XAI:** 10-stage local timeline, 8-stage online timeline, WhyThisPaper breakdown
- **Enhanced RAG:** Claim verification (5 statuses), iterative refinement (max 2 cycles)
- **Context Engine:** 5 modes, 5 scopes, SHA-256 hashing
- **Tech Stack:** React 19, FastAPI, PostgreSQL, ChromaDB, Gemini Flash
- **Status:** ~62% overall completion (implementation strong, evaluation pending)

## Anticipated Questions & Answers

### 1. What is completed?
- **Core Pipelines:** Local (hybrid) and online retrieval pipelines are fully implemented and functional.
- **Explainability (XAI):** 10-stage local and 8-stage online transparency timelines are operational.
- **Enhanced RAG Engine:** Claim verification, evidence deduplication, and iterative refinement are built.
- **Infrastructure:** React frontend, FastAPI backend, PostgreSQL database, and ChromaDB vector store are integrated.

### 2. What is novel?
- **Integration:** Combines hybrid retrieval, XAI transparency, context-bound RAG, and claim verification in a single workspace.
- **Engineering Contribution:** robust pipeline combining off-the-shelf tools for a transparent research workflow.
- **Research Contribution:** Exploring the impact of explicitly explaining retrieval decisions (XAI) on user trust and RAG quality.
- **Honesty Check:** We do not claim novel foundational model architectures, but rather novel integration and application of transparency in RAG.

### 3. Why hybrid retrieval?
- **Precision:** BM25 captures exact, critical keyword matches that dense vectors often miss.
- **Semantics:** Dense embeddings (ChromaDB) capture conceptual similarities and synonyms.
- **Robust Fusion:** Reciprocal Rank Fusion (RRF) effectively merges both signals without needing learned, domain-specific weights.

### 4. Why XAI?
- **Trust:** Researchers need transparency for critical decisions; black-box systems are insufficient.
- **Justification:** Users must understand *why* a paper was selected (e.g., BM25 score vs. Semantic score), not just *that* it was.
- **Debugging:** Exposes the internal workings of the retrieval and RAG pipeline for ongoing refinement.

### 5. Why Enhanced RAG?
- **Grounding:** Basic RAG often hallucinates or relies on internal knowledge instead of the provided text.
- **Strict Scoping:** Enforces strict adherence to user-defined context boundaries.
- **Verification:** Adds crucial steps like evidence deduplication, claim verification, and conservative citation repair.

### 6. How does it differ from Google Scholar?
- **Beyond Search:** Google Scholar stops at retrieving document links.
- **Transparency:** ResearchNexus details the exact mechanics of why a document matched.
- **Synthesis:** Provides evidence-grounded, synthesized answers with verified claims, rather than just a list of links.

### 7. How does it differ from OpenScholar?
- **Scale:** OpenScholar uses massive resources (45M papers, 8B parameter retriever, custom training).
- **Our Approach:** ResearchNexus uses a focused local corpus (706 papers) and off-the-shelf BGE reranking without custom training.
- **Focus:** We emphasize the XAI pipeline and an integrated research workspace, not foundational model parity.

### 8. How are citations verified?
- **Deterministic Stage:** Checks for direct numerical matches and explicit negations.
- **Semantic Stage:** Uses an LLM restricted strictly to zero outside knowledge to evaluate semantic alignment.
- **Repair:** Employs a conservative citation repair mechanism for claims that lack proper citations.

### 9. What is currently measured?
- **Unit Testing:** 37 specific XAI tests are passing, ensuring pipeline mechanics work.
- **System Health:** Builds are clean and operational.
- **Performance:** Pipeline latency is actively logged.
- **Status:** Formal experimental evaluation on retrieval/RAG quality is pending.

### 10. What is still experimental?
- **Quality Metrics:** Retrieval accuracy (NDCG, Recall) and RAG response quality.
- **Verification Efficacy:** The actual accuracy of claim verification and citation assignment.
- **Refinement Impact:** The quantitative benefit of iterative refinement cycles.
- **Note:** All these are current hypotheses awaiting empirical validation.

### 11. What are the limitations?
- **Scale & Scope:** Small local corpus (706 papers) across limited domains.
- **Components:** Relies on an off-the-shelf reranker rather than a domain-tuned model.
- **Data Quality:** Variability in online source APIs and potential issues with PDF text extraction.
- **Evaluation:** No human evaluation conducted yet.

### 12. What percentage is complete?
- **Overall:** Approximately 57% completed.
- **Implementation:** ~85% finished (core systems are built).
- **Evaluation:** ~5% finished (pending formal experiments).
- **Documentation:** IEEE paper drafting has not yet started.

### 13. What remains before final submission?
- **Experiments:** Execute the 8 planned experimental evaluations to gather data.
- **Testing:** Comprehensive end-to-end and integration testing.
- **Writing:** Drafting and finalizing the IEEE paper based on experimental results.
- **Deployment & Review:** Production deployment and potential small-scale human evaluation if time permits.
