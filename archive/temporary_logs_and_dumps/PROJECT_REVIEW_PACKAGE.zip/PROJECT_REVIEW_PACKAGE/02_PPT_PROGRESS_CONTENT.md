# ResearchNexus AI - 5-6 Week Progress Presentation Content

## Slide 1: Title
**Title:** ResearchNexus AI: An Explainable Research Assistant Using Hybrid Retrieval, XAI and Enhanced RAG
**Content:**
*   **Project:** ResearchNexus AI
*   **Focus:** Explainable Research Assistant
*   **Core Technologies:** Hybrid Retrieval, eXplainable AI (XAI), Enhanced RAG
*   **Date:** [Insert Date]
*   **Team/Presenter:** [Insert Name]

**Visual/Diagram Recommendation:** Clean, professional title layout with the project logo and simple abstract tech background.
**Speaker Notes:** Welcome everyone. Today, I'll be sharing our progress on ResearchNexus AI over the past 5 to 6 weeks. Our goal is to present an explainable research assistant that leverages hybrid retrieval, XAI, and enhanced RAG.

---

## Slide 2: Problem & Motivation
**Title:** The Research Challenge
**Content:**
*   Information overload in academic literature
*   Limitations of traditional search (e.g., Google Scholar): lack of transparency and deep synthesis
*   Shortcomings of standard RAG: hallucinations, unverified claims, opaque retrieval
*   Need for verifiable, transparent, and grounded research assistance

**Visual/Diagram Recommendation:** Split graphic contrasting a frustrated researcher overwhelmed by papers vs. a structured, transparent AI pipeline.
**Speaker Notes:** Researchers today face massive information overload. Traditional tools like Google Scholar lack deep synthesis, while standard RAG systems suffer from hallucinations and opaque retrieval mechanisms. ResearchNexus AI addresses these by providing transparency and verifiable, grounded evidence.

---

## Slide 3: System Architecture
**Title:** System Architecture
**Content:**
*   **Frontend:** React 19, Vite, Tailwind
*   **Backend API:** FastAPI
*   **Storage & DB:** PostgreSQL, ChromaDB
*   **AI/LLM:** Gemini Flash, BAAI/bge-base-en-v1.5 (768d)
*   **Core Flow:** Frontend → API → Services → Retrieval → Evidence → RAG → XAI → LLM → Storage

**Visual/Diagram Recommendation:** Layered architecture diagram showing the flow from the React Frontend through the FastAPI backend to the DBs and LLM integration.
**Speaker Notes:** Our tech stack is built for speed and reliability. We use React 19 and FastAPI, backed by PostgreSQL and ChromaDB for high-performance vector storage. The core flow ensures every user query passes through robust retrieval, evidence generation, and XAI layers before hitting the LLM.

---

## Slide 4: Research Explorer
**Title:** Research Explorer
**Content:**
*   Unified interface for deep literature search
*   Real-time polling for asynchronous search task completion
*   Simultaneous local and online result aggregation
*   Integrated search history tracking

**Visual/Diagram Recommendation:** Screenshot or mockup of the Research Explorer UI highlighting the search bar, real-time polling indicator, and mixed local/online results.
**Speaker Notes:** The Research Explorer acts as the central hub for literature search. We've implemented real-time polling for smooth asynchronous tasks. It seamlessly aggregates results from both our local datasets and online connectors, maintaining a full search history.

---

## Slide 5: Local Retrieval Pipeline
**Title:** Local Retrieval Pipeline
**Content:**
*   **Dataset:** 706 verified papers across 3 domains
*   **Vector DB:** ChromaDB backfilled with 26,179 verified embeddings
*   **Pipeline Stages:**
    *   PostgreSQL metadata filtering
    *   BM25 keyword search
    *   Dense vector search
    *   Reciprocal Rank Fusion (RRF)
    *   Filtering & Diversification
    *   BGE Reranking

**Visual/Diagram Recommendation:** Flowchart detailing the stages of the local retrieval pipeline, incorporating the 706 papers and 26K embeddings statistics.
**Speaker Notes:** Our local pipeline is highly optimized, operating on a dataset of 706 papers and over 26,000 verified embeddings. It uses a robust multi-stage approach, combining PostgreSQL metadata filtering, BM25, dense search, and BGE reranking to surface the most relevant documents.

---

## Slide 6: Hybrid Retrieval + RRF
**Title:** Hybrid Retrieval & Reciprocal Rank Fusion
**Content:**
*   **Fusion Strategy:** BM25 (keyword) + Dense (semantic) fused via RRF (k=60)
*   Addresses vocabulary mismatch and semantic gaps
*   **Online Connectors:**
    *   arXiv
    *   OpenAlex
    *   PMC
    *   AGRIS
    *   NASA ADS

**Visual/Diagram Recommendation:** Diagram showing two streams (BM25 and Dense) merging into an RRF block, alongside the 5 online API connector logos/names feeding into a unified results list.
**Speaker Notes:** To maximize retrieval quality, we fuse keyword-based BM25 and semantic dense search using Reciprocal Rank Fusion with a k-value of 60. Additionally, we integrate live data from five major academic connectors, including arXiv, OpenAlex, and PubMed Central.

---

## Slide 7: XAI Implementation
**Title:** Explainable AI (XAI) Implementation
**Content:**
*   10-stage local pipeline timeline
*   8-stage online pipeline timeline
*   Complete XAI trace visibility
*   "Why This Paper?" feature for retrieved documents
*   BGE rank independence fixed, search_id validation applied
*   37 rigorous XAI tests passed

**Visual/Diagram Recommendation:** UI snapshot of the 10-stage timeline UI showing the execution trace and the "Why This Paper?" popover.
**Speaker Notes:** Transparency is critical in research. Our XAI implementation exposes a 10-stage local timeline and an 8-stage online timeline. We've ensured complete trace visibility, fixed rank independence issues, and successfully passed 37 dedicated XAI validation tests.

---

## Slide 8: AI Assistant Workspace
**Title:** AI Assistant Workspace
**Content:**
*   5 distinct interaction modes
*   Context Inspector for full transparency
*   Scope Engine for bounding queries
*   Context Snapshots (Immutable, SHA-256 hashed)
*   Targeted context for generation

**Visual/Diagram Recommendation:** Mockup of the workspace highlighting the context inspector, scope engine toggles, and snapshot hashing.
**Speaker Notes:** The AI Assistant Workspace gives users complete control over the AI's context. It features 5 interaction modes, a scope engine, and immutable context snapshots secured with SHA-256 hashing to ensure reproducibility and transparency.

---

## Slide 9: Enhanced RAG Pipeline
**Title:** Enhanced RAG Pipeline
**Content:**
*   **Eligibility Check:** Determine if query requires RAG
*   **Retrieval:** Fetch grounded context
*   **Deduplication:** Remove redundant evidence
*   **Context Assembly:** Build structured prompt
*   **Generation:** Initial LLM response
*   **Verification:** Automatic claim checking

**Visual/Diagram Recommendation:** A linear block diagram or chevron list showing the 6 steps from Eligibility to Verification.
**Speaker Notes:** Our Enhanced RAG pipeline is far more rigorous than standard approaches. It moves from strict eligibility checks and deduplication to context assembly, followed by generation and a mandatory automatic claim verification step.

---

## Slide 10: Claim Verification
**Title:** Automated Claim Verification
**Content:**
*   Extracts 6 different types of claims
*   Applies deterministic checks (metadata, dates)
*   Utilizes semantic LLM verification for complex claims
*   Outputs 5 distinct verification statuses
*   Features automatic citation repair

**Visual/Diagram Recommendation:** Visual grid or table showing claim types on one side and the verification workflow (extraction, check, status, repair) on the other.
**Speaker Notes:** We automatically verify generated content by extracting six types of claims. We use deterministic checks for metadata and LLM-based semantic verification for complex statements. If citations are misaligned, the system attempts automatic citation repair.

---

## Slide 11: Iterative Refinement
**Title:** Bounded Iterative Refinement
**Content:**
*   Generates initial answer & runs verification
*   Evaluates self-feedback on failures
*   Executes targeted secondary retrieval
*   Refines output and re-verifies
*   Maximum 2 cycles to prevent infinite loops
*   Anti-oscillation mechanisms built-in

**Visual/Diagram Recommendation:** A cyclical loop diagram showing Answer → Verify → Feedback → Refine, with a prominent "Max 2 Cycles" stop condition.
**Speaker Notes:** When verification fails, the system enters an iterative refinement loop. It generates self-feedback and performs targeted retrieval to fix errors. To maintain efficiency and prevent infinite loops, we cap this process at two cycles with anti-oscillation safeguards.

---

## Slide 12: Testing & Validation
**Title:** Testing & Validation
**Content:**
*   Clean backend builds
*   37 complete XAI tests passed
*   Robust backend testing suite implementation
*   Validation of search_id continuity
*   Verification of BGE reranking correctness

**Visual/Diagram Recommendation:** A stylized dashboard or checklist showing green checkmarks for test suites, build status, and XAI test passes.
**Speaker Notes:** Quality assurance has been a major focus over the last few weeks. We have a clean build, a robust backend testing suite, and we have specifically passed 37 complex XAI tests, validating our trace completeness and reranking algorithms.

---

## Slide 13: Current Completion %
**Title:** Project Status & Completion
**Content:**
*   **Overall Project Completion:** ~62%
*   **Data & Embedding:** 100%
*   **Retrieval Pipeline:** 90%
*   **XAI Components:** 85%
*   **Enhanced RAG:** 70%
*   **Evaluation & Tuning:** 10%

**Visual/Diagram Recommendation:** A simplified weighted completion table or progress bar chart reflecting the ~62% overall completion and individual module progress.
**Speaker Notes:** We are currently at roughly 62% completion overall. Implementation is strong, with data, retrieval pipelines, and XAI largely complete. Our next major focus shifts heavily toward system evaluation and fine-tuning.

---

## Slide 14: Research Contribution
**Title:** Key Research Contributions
**Content:**
1.  Hybrid Local+Online research retrieval with RRF
2.  Retrieval-level XAI (10-stage pipeline transparency)
3.  Context-bound evidence-grounded Enhanced RAG
4.  Claim→Evidence verification with citation repair
5.  Bounded iterative refinement with anti-oscillation
6.  Research-oriented workspace with immutable context snapshots

**Visual/Diagram Recommendation:** A numbered list with distinct icons for each contribution highlighting novelty compared to standard tools.
**Speaker Notes:** Our system introduces several novel contributions to the field. These include our highly transparent retrieval-level XAI, robust claim-to-evidence verification with automated repair, and a unique bounded iterative refinement mechanism designed specifically for academic research.

---

## Slide 15: Next Steps
**Title:** Next Steps & Future Work
**Content:**
*   Formal system evaluation and metrics gathering
*   Conducting user experiments and A/B testing
*   Completion of remaining analytics features
*   Drafting the IEEE research paper

**Visual/Diagram Recommendation:** A timeline or roadmap graphic outlining the next 4-6 weeks to project completion and paper submission.
**Speaker Notes:** Looking ahead, our primary goals are formal evaluation and user experiments to gather concrete metrics. We will also finalize the remaining analytics features and focus on drafting our findings for an IEEE publication.
